require('dotenv').config();
const express = require('express');
const { createRequestHandler } = require('@remix-run/express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, '../public')));

// Remix request handler
app.all(
  '*',
  createRequestHandler({
    build: require(path.join(__dirname, '../webgen_frontend/build')),
    mode: process.env.NODE_ENV
  })
);

app.listen(PORT, () => {
  console.log(`✅ Webgen backend listening on port ${PORT}`);
});
